package buzz_reservation;
import java.util.*;

public class Booking {
	String passengerName;
	Date d;
	
}
