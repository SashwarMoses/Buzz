package buzz_reservation;

import java.util.ArrayList;
import java.util.Scanner;

public class BuzzApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Bus> buses = new ArrayList<Bus>(); 
		buses.add(new Bus(1,"A",50));
		buses.add(new Bus(2,"N/A",45));
		buses.add(new Bus(3,"A",48));
		int bookOpt =1;
		while (bookOpt == 1){
			System.out.println("Enter 1 to book and 2 to exit");
			Scanner s = new Scanner(System.in);
			bookOpt = s.nextInt();
			continue;
			}
	}

}
